﻿namespace Decrypt
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.EncryptBtn = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.KeyLb = new System.Windows.Forms.Label();
            this.ToEncryptLb = new System.Windows.Forms.Label();
            this.DecryptLb = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.EncryptedLb = new System.Windows.Forms.Label();
            this.DecryptBtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // EncryptBtn
            // 
            this.EncryptBtn.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EncryptBtn.Location = new System.Drawing.Point(23, 115);
            this.EncryptBtn.Name = "EncryptBtn";
            this.EncryptBtn.Size = new System.Drawing.Size(273, 35);
            this.EncryptBtn.TabIndex = 0;
            this.EncryptBtn.Text = "Encrypt";
            this.EncryptBtn.UseVisualStyleBackColor = true;
            this.EncryptBtn.Click += new System.EventHandler(this.EncryptBtn_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(127, 20);
            this.textBox1.Name = "textBox1";
            this.textBox1.PasswordChar = '*';
            this.textBox1.Size = new System.Drawing.Size(169, 20);
            this.textBox1.TabIndex = 2;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(127, 58);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(169, 20);
            this.textBox2.TabIndex = 3;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(23, 191);
            this.textBox3.Multiline = true;
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(273, 65);
            this.textBox3.TabIndex = 4;
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(127, 330);
            this.textBox4.Name = "textBox4";
            this.textBox4.PasswordChar = '*';
            this.textBox4.Size = new System.Drawing.Size(169, 20);
            this.textBox4.TabIndex = 5;
            // 
            // textBox5
            // 
            this.textBox5.BackColor = System.Drawing.SystemColors.Control;
            this.textBox5.Location = new System.Drawing.Point(127, 365);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(169, 20);
            this.textBox5.TabIndex = 6;
            // 
            // KeyLb
            // 
            this.KeyLb.AutoSize = true;
            this.KeyLb.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.KeyLb.Location = new System.Drawing.Point(23, 19);
            this.KeyLb.Name = "KeyLb";
            this.KeyLb.Size = new System.Drawing.Size(41, 21);
            this.KeyLb.TabIndex = 7;
            this.KeyLb.Text = "Key:";
            // 
            // ToEncryptLb
            // 
            this.ToEncryptLb.AutoSize = true;
            this.ToEncryptLb.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ToEncryptLb.Location = new System.Drawing.Point(19, 58);
            this.ToEncryptLb.Name = "ToEncryptLb";
            this.ToEncryptLb.Size = new System.Drawing.Size(96, 21);
            this.ToEncryptLb.TabIndex = 8;
            this.ToEncryptLb.Text = "To Encrypt:";
            // 
            // DecryptLb
            // 
            this.DecryptLb.AutoSize = true;
            this.DecryptLb.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DecryptLb.Location = new System.Drawing.Point(19, 362);
            this.DecryptLb.Name = "DecryptLb";
            this.DecryptLb.Size = new System.Drawing.Size(98, 21);
            this.DecryptLb.TabIndex = 10;
            this.DecryptLb.Text = "Decrypted:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(23, 327);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(41, 21);
            this.label2.TabIndex = 9;
            this.label2.Text = "Key:";
            // 
            // EncryptedLb
            // 
            this.EncryptedLb.AutoSize = true;
            this.EncryptedLb.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EncryptedLb.Location = new System.Drawing.Point(23, 167);
            this.EncryptedLb.Name = "EncryptedLb";
            this.EncryptedLb.Size = new System.Drawing.Size(95, 21);
            this.EncryptedLb.TabIndex = 11;
            this.EncryptedLb.Text = "Encrypted:";
            // 
            // DecryptBtn
            // 
            this.DecryptBtn.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DecryptBtn.Location = new System.Drawing.Point(23, 274);
            this.DecryptBtn.Name = "DecryptBtn";
            this.DecryptBtn.Size = new System.Drawing.Size(273, 35);
            this.DecryptBtn.TabIndex = 12;
            this.DecryptBtn.Text = "Decrypt";
            this.DecryptBtn.UseVisualStyleBackColor = true;
            this.DecryptBtn.Click += new System.EventHandler(this.DecryptBtn_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(332, 401);
            this.Controls.Add(this.DecryptBtn);
            this.Controls.Add(this.EncryptedLb);
            this.Controls.Add(this.DecryptLb);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.ToEncryptLb);
            this.Controls.Add(this.KeyLb);
            this.Controls.Add(this.textBox5);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.EncryptBtn);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button EncryptBtn;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.Label KeyLb;
        private System.Windows.Forms.Label ToEncryptLb;
        private System.Windows.Forms.Label DecryptLb;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label EncryptedLb;
        private System.Windows.Forms.Button DecryptBtn;
    }
}

